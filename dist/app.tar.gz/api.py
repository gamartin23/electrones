from flask import Flask, jsonify, request
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address


app = Flask(__name__)

count = 0 

limiter = Limiter(
    get_remote_address, 
    app=app,
    default_limits=["5 per minute"],
)

@app.route('/', methods=['GET'])
@limiter.limit("100 per minute")
def get_count():
  global count
  return jsonify({"count": count})

@app.route('/', methods=['POST'])
@limiter.limit("100 per minute")
def increment_count():
  global count
  count += 1
  return jsonify({"count": count}) 

if __name__ == '__main__':
  app.run()